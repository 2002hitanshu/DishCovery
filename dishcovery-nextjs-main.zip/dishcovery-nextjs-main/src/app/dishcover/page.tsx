import DishcoveryForm from "@/components/recommendForm";

export const metadata = {
    title: 'Discover',
}
export default function Recommend() {
    return (
        <>
            <DishcoveryForm />
        </>
    )
}