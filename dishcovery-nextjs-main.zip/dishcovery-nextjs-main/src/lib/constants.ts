const APP_NAME = 'Dishcovery';

export { APP_NAME };
